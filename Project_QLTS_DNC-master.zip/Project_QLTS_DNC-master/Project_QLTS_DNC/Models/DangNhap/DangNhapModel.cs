﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Project_QLTS_DNC.Models.DangNhap
{
    public class DangNhapModel
    {
        public string Email { get; set; }
        public string MatKhau { get; set; }
    }
}

