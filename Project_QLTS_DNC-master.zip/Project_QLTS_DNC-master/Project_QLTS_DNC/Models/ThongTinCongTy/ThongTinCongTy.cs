﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Project_QLTS_DNC.Models.ThongTinCongTy
{
    public class ThongTinCongTy
    {
        public string Ten { get; set; }
        public string MaSoThue { get; set; }
        public string DiaChi { get; set; }
        public string SoDienThoai { get; set; }
        public string Email { get; set; }
        public string NguoiDaiDien { get; set; }
        public string GhiChu { get; set; }
        public string LogoPath { get; set; }

        public string PdfPath { get; set; }

    }
}
