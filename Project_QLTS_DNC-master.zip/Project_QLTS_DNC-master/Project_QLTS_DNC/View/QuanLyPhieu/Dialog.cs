﻿namespace Project_QLTS_DNC.View.QuanLyPhieu
{
    internal class Dialog
    {
        public string Title { get; set; }
        public object Content { get; set; }
        public int Width { get; set; }
        public int Height { get; set; }
    }
}